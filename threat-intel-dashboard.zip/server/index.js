import express from 'express';
import http from 'http';
import { WebSocketServer } from 'ws';
import cors from 'cors';
import { initDB, getDB } from './db.js';
import { startCronJobs } from './cron.js';
import { runAllFeeds } from './feeds/index.js';

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

app.use(cors());
app.use(express.json());

// Initialize database
initDB();

// WebSocket connections
const clients = new Set();
wss.on('connection', (ws) => {
  clients.add(ws);
  console.log(`[WS] Client connected. Total: ${clients.size}`);
  ws.on('close', () => {
    clients.delete(ws);
    console.log(`[WS] Client disconnected. Total: ${clients.size}`);
  });
});

export function broadcast(type, data) {
  const msg = JSON.stringify({ type, data, timestamp: new Date().toISOString() });
  for (const client of clients) {
    if (client.readyState === 1) {
      client.send(msg);
    }
  }
}

// =================== API ROUTES ===================

// GET /api/iocs — paginated list
app.get('/api/iocs', (req, res) => {
  const db = getDB();
  const limit = Math.min(parseInt(req.query.limit) || 100, 50000);
  const offset = parseInt(req.query.offset) || 0;
  const source = req.query.source || '';
  const search = req.query.search || '';
  const iocType = req.query.ioc_type || '';
  const days = parseInt(req.query.days) || 0;

  let query = 'SELECT * FROM iocs WHERE 1=1';
  const params = [];

  if (days > 0) { query += " AND created_at > datetime('now', ?)"; params.push(`-${days} day`); }
  if (source) { query += ' AND source = ?'; params.push(source); }
  if (iocType) { query += ' AND ioc_type = ?'; params.push(iocType); }
  if (search) { query += ' AND (ioc LIKE ? OR malware LIKE ? OR tags LIKE ?)'; params.push(`%${search}%`, `%${search}%`, `%${search}%`); }

  query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
  params.push(limit, offset);

  const iocs = db.prepare(query).all(...params);
  const total = db.prepare('SELECT COUNT(*) as count FROM iocs').get();

  // Helper for safe JSON parsing
  const safeParse = (str, fallback) => {
    try {
      const parsed = JSON.parse(str || 'null');
      return (parsed !== null && typeof parsed === typeof fallback) ? parsed : fallback;
    } catch { return fallback; }
  };

  // Parse JSON fields
  const parsed = iocs.map(ioc => ({
    ...ioc,
    tags: safeParse(ioc.tags, []),
    enrichment: safeParse(ioc.enrichment, {}),
    mitre_techniques: safeParse(ioc.mitre_techniques, []),
  }));

  res.json({ iocs: parsed, total: total.count });
});

// POST /api/iocs — add custom IoC
app.post('/api/iocs', (req, res) => {
  const db = getDB();
  const { ioc, ioc_type, malware_printable, confidence_level, tags } = req.body;
  
  if (!ioc || !ioc_type) {
    return res.status(400).json({ error: 'Missing required fields: ioc, ioc_type' });
  }

  try {
    const result = db.prepare(`
      INSERT INTO iocs (ioc, ioc_type, malware_printable, confidence_level, source, tags, first_seen)
      VALUES (?, ?, ?, ?, 'Custom Intel', ?, datetime('now'))
    `).run(ioc, ioc_type, malware_printable || '', parseInt(confidence_level) || 100, JSON.stringify(tags || []));
    
    // Broadcast real-time update
    broadcast('new_iocs', { count: result.changes });
    res.json({ ok: true, id: result.lastInsertRowid });
  } catch (err) {
    if (err.message.includes('UNIQUE')) {
      return res.status(409).json({ error: 'This IoC already exists.' });
    }
    res.status(500).json({ error: err.message });
  }
});

// GET /api/stats — dashboard statistics
app.get('/api/stats', (req, res) => {
  const db = getDB();
  const totalIocs = db.prepare('SELECT COUNT(*) as count FROM iocs').get().count;
  const bySource = db.prepare('SELECT source, COUNT(*) as count FROM iocs GROUP BY source').all();
  const byType = db.prepare('SELECT ioc_type, COUNT(*) as count FROM iocs GROUP BY ioc_type').all();
  const recent24h = db.prepare("SELECT COUNT(*) as count FROM iocs WHERE created_at > datetime('now', '-1 day')").get().count;
  const feeds = db.prepare('SELECT name, enabled, last_polled FROM feeds').all();

  res.json({ totalIocs, bySource, byType, recent24h, feeds });
});

// GET /api/stats/trend — last 7 days aggregation
app.get('/api/stats/trend', (req, res) => {
  const db = getDB();
  const trend = db.prepare(`
    WITH RECURSIVE days(d) AS (
      SELECT date('now', '-6 days')
      UNION ALL
      SELECT date(d, '+1 day') FROM days WHERE d < date('now')
    )
    SELECT 
      CASE strftime('%w', d.d)
        WHEN '0' THEN 'Sun' WHEN '1' THEN 'Mon' WHEN '2' THEN 'Tue'
        WHEN '3' THEN 'Wed' WHEN '4' THEN 'Thu' WHEN '5' THEN 'Fri'
        WHEN '6' THEN 'Sat' ELSE '???'
      END as name,
      COUNT(i.id) as threats
    FROM days d
    LEFT JOIN iocs i ON date(i.created_at, 'localtime') = d.d
    GROUP BY d.d
    ORDER BY d.d ASC
  `).all();
  
  res.json(trend);
});

// GET /api/oracle/forecast — Dynamic threat forecasting
app.get('/api/oracle/forecast', (req, res) => {
  const db = getDB();
  
  // 1. Calculate IoC Velocity (Last 24h vs Avg of last 7 days)
  const recent24h = db.prepare("SELECT COUNT(*) as count FROM iocs WHERE created_at > datetime('now', '-1 day')").get().count;
  const last7d = db.prepare("SELECT COUNT(*) as count FROM iocs WHERE created_at > datetime('now', '-7 days')").get().count;
  const avgPd = last7d / 7;
  const velocity = avgPd > 0 ? (recent24h / avgPd) : 1;
  
  // 2. Malware Diversity (Unique families in last 3 days)
  const malwareCount = db.prepare("SELECT COUNT(DISTINCT malware) as count FROM iocs WHERE malware != '' AND created_at > datetime('now', '-3 days')").get().count;
  
  // 3. Base Likelihood Calculation
  // Base 30% + (Velocity * 10) + (MalwareDiversity * 2) capped at 95%
  let likelihood = 30 + (velocity * 10) + (malwareCount * 2);
  likelihood = Math.min(Math.round(likelihood), 95);

  // 4. Sector Probabilities (weighted by source/tags)
  const sectors = [
    { sector: 'Financial Services', base: 40, keywords: ['bank', 'finance', 'payment'] },
    { sector: 'Supply Chain / MSPs', base: 35, keywords: ['supply', 'msp', 'it'] },
    { sector: 'Healthcare', base: 30, keywords: ['health', 'hospital', 'medical'] },
    { sector: 'Critical Infrastructure', base: 45, keywords: ['energy', 'grid', 'water'] },
    { sector: 'Government & Defense', base: 50, keywords: ['gov', 'mil', 'defense'] },
  ];

  const sectorThreats = sectors.map(s => {
    // Count IoCs tagged with relevant keywords in last 7 days
    const tagMatch = db.prepare(`SELECT COUNT(*) as count FROM iocs WHERE (tags LIKE ? OR ioc LIKE ?) AND created_at > datetime('now', '-7 days')`)
      .get(`%${s.keywords[0]}%`, `%${s.keywords[0]}%`).count;
    
    let prob = s.base + (tagMatch * 5) + (velocity * 2);
    return {
      sector: s.sector,
      probability: Math.min(Math.round(prob), 98),
      trend: velocity > 1.2 ? 'up' : velocity < 0.8 ? 'down' : 'stable',
      primaryActor: 'Multiple Clusters'
    };
  });

  // 5. Generate forecast graph data (7 days)
  const forecastData = [];
  for(let i=0; i<7; i++) {
    const d = new Date();
    d.setDate(d.getDate() + i);
    const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
    // Add some "jitter" based on velocity
    const dayLikelihood = Math.min(Math.max(likelihood + (Math.sin(i) * 10) * velocity, 20), 99);
    forecastData.push({
      day: dayName,
      likelihood: Math.round(dayLikelihood),
      activeThreats: Math.round(recent24h / 10 + (Math.random() * 5))
    });
  }

  res.json({
    likelihood,
    velocity: velocity.toFixed(2),
    malwareDiversity: malwareCount,
    sectorThreats,
    forecastData,
    summary: `The Oracle has detected a ${velocity > 1.5 ? 'significant spike' : 'steady flow'} of ${malwareCount} unique malware variants. Relative velocity is ${velocity.toFixed(2)}x normal levels.`
  });
});

// GET /api/feeds — list feeds
app.get('/api/feeds', (req, res) => {
  const db = getDB();
  const feeds = db.prepare('SELECT * FROM feeds').all();
  res.json(feeds);
});

// PUT /api/feeds/:id — toggle feed
app.put('/api/feeds/:id', (req, res) => {
  const db = getDB();
  const { enabled } = req.body;
  db.prepare('UPDATE feeds SET enabled = ? WHERE id = ?').run(enabled ? 1 : 0, req.params.id);
  res.json({ ok: true });
});

// GET /api/alerts — recent alerts
app.get('/api/alerts', (req, res) => {
  const db = getDB();
  const alerts = db.prepare('SELECT * FROM alerts ORDER BY created_at DESC LIMIT 50').all();
  res.json(alerts);
});

// GET/PUT /api/settings — key-value settings
app.get('/api/settings', (req, res) => {
  const db = getDB();
  const rows = db.prepare('SELECT * FROM settings').all();
  const settings = {};
  for (const r of rows) settings[r.key] = r.value;
  res.json(settings);
});

app.put('/api/settings', (req, res) => {
  const db = getDB();
  const upsert = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
  for (const [key, value] of Object.entries(req.body)) {
    upsert.run(key, String(value));
  }
  res.json({ ok: true });
});

// GET /api/news — list news articles
app.get('/api/news', (req, res) => {
  const db = getDB();
  const limit = Math.min(parseInt(req.query.limit) || 50, 200);
  const news = db.prepare('SELECT * FROM news ORDER BY published_at DESC LIMIT ?').all(limit);
  res.json(news);
});

// POST /api/sync — force-run all feeds now
app.post('/api/sync', async (req, res) => {
  try {
    const result = await runAllFeeds();
    res.json({ ok: true, result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/correlations — find related IoCs
app.get('/api/correlations', (req, res) => {
  const db = getDB();
  const ioc = req.query.ioc;
  if (!ioc) return res.json([]);

  // Find IoCs sharing the same malware family
  const target = db.prepare('SELECT * FROM iocs WHERE ioc = ?').get(ioc);
  if (!target) return res.json([]);

  const related = db.prepare(
    'SELECT * FROM iocs WHERE malware = ? AND ioc != ? LIMIT 20'
  ).all(target.malware, ioc);

  res.json({ target, related });
});

// GET /api/investigate/:id — Aggregate investigation brief
app.get('/api/investigate/:id', async (req, res) => {
  const db = getDB();
  const id = req.params.id;
  
  const ioc = db.prepare('SELECT * FROM iocs WHERE id = ?').get(id);
  if (!ioc) return res.status(404).json({ error: 'IoC not found' });

  // 1. Get Correlations
  const related = db.prepare('SELECT * FROM iocs WHERE malware = ? AND id != ? LIMIT 10').all(ioc.malware, id);

  // 2. Mock AI Brief Generation
  const brief = {
    summary: `This ${ioc.ioc_type} indicator was first identified on ${ioc.first_seen}. It is strongly associated with the ${ioc.malware || 'unidentified'} malware family. Indicators show this infrastructure is likely part of a broader campaign targeting ${JSON.parse(ioc.tags || '[]').join(', ') || 'multiple sectors'}.`,
    risk_score: ioc.confidence_level || 75,
    recommended_action: ioc.ioc_type === 'ipv4' ? 'Block at Egress Firewall' : ioc.ioc_type === 'domain' ? 'DNS Sinkhole' : 'Purge from Endpoints',
    historical_hits: related.length,
    threat_actor_match: ioc.malware === 'Trickbot' ? 'Lazarus Group (Cluster)' : 'Generic Cybercrime'
  };

  res.json({ ioc, related, brief });
});

// POST /api/sandbox — Mock sandbox submission
app.post('/api/sandbox', (req, res) => {
  const { ioc, type } = req.body;
  const db = getDB();
  
  const jobId = `SB-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
  
  // Return mock successful submission
  res.json({ 
    ok: true, 
    jobId, 
    status: 'In Progress', 
    target: ioc,
    eta: '45 seconds'
  });
});

// =================== START ===================
const PORT = process.env.PORT || 3001;

// Run feeds on startup
setTimeout(async () => {
  console.log('[STARTUP] Running initial feed ingestion...');
  try {
    await runAllFeeds();
    console.log('[STARTUP] Initial feed ingestion complete.');
  } catch (err) {
    console.error('[STARTUP] Feed ingestion error:', err.message);
  }
}, 2000);

// Start cron jobs
startCronJobs();

server.listen(PORT, '0.0.0.0', () => {
  console.log(`[SERVER] Threat Intel Backend running on http://0.0.0.0:${PORT}`);
  console.log(`[WS] WebSocket server ready on ws://0.0.0.0:${PORT}`);
});
